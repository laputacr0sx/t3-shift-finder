create function graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb)
    returns jsonb
    language sql
as
$$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

alter function graphql(text, text, jsonb, jsonb) owner to supabase_admin;

grant execute on function graphql(text, text, jsonb, jsonb) to postgres;

grant execute on function graphql(text, text, jsonb, jsonb) to anon;

grant execute on function graphql(text, text, jsonb, jsonb) to authenticated;

grant execute on function graphql(text, text, jsonb, jsonb) to service_role;

