create function get_auth(p_usename text)
    returns TABLE(username text, password text)
    security definer
    language plpgsql
as
$$
BEGIN
    RAISE WARNING 'PgBouncer auth request: %', p_usename;

    RETURN QUERY
    SELECT usename::TEXT, passwd::TEXT FROM pg_catalog.pg_shadow
    WHERE usename = p_usename;
END;
$$;

alter function get_auth(text) owner to postgres;

grant execute on function get_auth(text) to pgbouncer;

