create function foldername(name text)
    returns text[]
    language plpgsql
as
$$
DECLARE
_parts text[];
BEGIN
    select string_to_array(name, '/') into _parts;
    return _parts[1:array_length(_parts,1)-1];
END
$$;

alter function foldername(text) owner to supabase_storage_admin;

grant execute on function foldername(text) to postgres;

grant execute on function foldername(text) to anon;

grant execute on function foldername(text) to authenticated;

grant execute on function foldername(text) to service_role;

grant execute on function foldername(text) to dashboard_user;

