create function trg_mask_update()
    returns event_trigger
    SET search_path =
            ""
    language plpgsql
as
$$
DECLARE
  r record;
BEGIN
  IF (select bool_or(in_extension) FROM pg_event_trigger_ddl_commands()) THEN
    RAISE NOTICE 'skipping pgsodium mask regeneration in extension';
	RETURN;
  END IF;
  PERFORM pgsodium.update_masks();
END
$$;

alter function trg_mask_update() owner to supabase_admin;

