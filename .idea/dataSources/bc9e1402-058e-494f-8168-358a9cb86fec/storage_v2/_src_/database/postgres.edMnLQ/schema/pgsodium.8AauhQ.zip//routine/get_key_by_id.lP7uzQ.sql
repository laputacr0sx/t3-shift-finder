create function get_key_by_id(uuid)
    returns pgsodium.valid_key
    security definer
    SET search_path =
            ""
    language sql
as
$$
    SELECT * from pgsodium.valid_key WHERE id = $1;
$$;

alter function get_key_by_id(uuid) owner to supabase_admin;

