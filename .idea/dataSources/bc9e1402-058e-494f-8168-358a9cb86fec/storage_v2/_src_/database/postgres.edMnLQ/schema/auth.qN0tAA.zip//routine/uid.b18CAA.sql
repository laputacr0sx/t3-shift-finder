create function uid()
    returns uuid
    stable
    language sql
as
$$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;

comment on function uid() is 'Deprecated. Use auth.jwt() -> ''sub'' instead.';

alter function uid() owner to supabase_auth_admin;

grant execute on function uid() to dashboard_user;

