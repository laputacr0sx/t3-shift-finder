create function get_key_by_name(text)
    returns pgsodium.valid_key
    security definer
    SET search_path =
            ""
    language sql
as
$$
    SELECT * from pgsodium.valid_key WHERE name = $1;
$$;

alter function get_key_by_name(text) owner to supabase_admin;

