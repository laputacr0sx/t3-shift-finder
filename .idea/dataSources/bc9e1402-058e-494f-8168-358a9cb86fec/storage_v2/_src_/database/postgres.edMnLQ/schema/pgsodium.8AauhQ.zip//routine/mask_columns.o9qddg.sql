create function mask_columns(source_relid oid)
    returns TABLE(attname name, key_id text, key_id_column text, associated_column text, nonce_column text, format_type text)
    language sql
as
$$
  SELECT
  a.attname,
  m.key_id,
  m.key_id_column,
  m.associated_column,
  m.nonce_column,
  m.format_type
  FROM pg_attribute a
  LEFT JOIN  pgsodium.masking_rule m
  ON m.attrelid = a.attrelid
  AND m.attname = a.attname
  WHERE  a.attrelid = source_relid
  AND    a.attnum > 0 -- exclude ctid, cmin, cmax
  AND    NOT a.attisdropped
  ORDER BY a.attnum;
$$;

alter function mask_columns(oid) owner to supabase_admin;

