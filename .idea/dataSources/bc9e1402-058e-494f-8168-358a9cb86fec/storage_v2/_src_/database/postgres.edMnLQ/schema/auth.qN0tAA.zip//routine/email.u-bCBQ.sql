create function email()
    returns text
    stable
    language sql
as
$$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;

comment on function email() is 'Deprecated. Use auth.jwt() -> ''email'' instead.';

alter function email() owner to supabase_auth_admin;

grant execute on function email() to dashboard_user;

