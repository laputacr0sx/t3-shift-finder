create function encrypted_column(relid oid, m record)
    returns text
    SET search_path =
            ""
    language plpgsql
as
$$
DECLARE
    expression TEXT;
    comma TEXT;
BEGIN
  expression := '';
  comma := E'        ';
  expression := expression || comma;
  IF m.format_type = 'text' THEN
	  expression := expression || format(
		$f$%s = CASE WHEN %s IS NULL THEN NULL ELSE
			CASE WHEN %s IS NULL THEN NULL ELSE pg_catalog.encode(
			  pgsodium.crypto_aead_det_encrypt(
				pg_catalog.convert_to(%s, 'utf8'),
				pg_catalog.convert_to((%s)::text, 'utf8'),
				%s::uuid,
				%s
			  ),
				'base64') END END$f$,
			'new.' || quote_ident(m.attname),
			'new.' || quote_ident(m.attname),
			COALESCE('new.' || quote_ident(m.key_id_column), quote_literal(m.key_id)),
			'new.' || quote_ident(m.attname),
			COALESCE(pgsodium.quote_assoc(m.associated_columns, true), quote_literal('')),
			COALESCE('new.' || quote_ident(m.key_id_column), quote_literal(m.key_id)),
			COALESCE('new.' || quote_ident(m.nonce_column), 'NULL')
	  );
  ELSIF m.format_type = 'bytea' THEN
	  expression := expression || format(
		$f$%s = CASE WHEN %s IS NULL THEN NULL ELSE
			CASE WHEN %s IS NULL THEN NULL ELSE
					pgsodium.crypto_aead_det_encrypt(%s::bytea, pg_catalog.convert_to((%s)::text, 'utf8'),
			%s::uuid,
			%s
		  ) END END$f$,
			'new.' || quote_ident(m.attname),
			'new.' || quote_ident(m.attname),
			COALESCE('new.' || quote_ident(m.key_id_column), quote_literal(m.key_id)),
			'new.' || quote_ident(m.attname),
			COALESCE(pgsodium.quote_assoc(m.associated_columns, true), quote_literal('')),
			COALESCE('new.' || quote_ident(m.key_id_column), quote_literal(m.key_id)),
			COALESCE('new.' || quote_ident(m.nonce_column), 'NULL')
	  );
  END IF;
  comma := E';\n        ';
  RETURN expression;
END
$$;

alter function encrypted_column(oid, record) owner to supabase_admin;

