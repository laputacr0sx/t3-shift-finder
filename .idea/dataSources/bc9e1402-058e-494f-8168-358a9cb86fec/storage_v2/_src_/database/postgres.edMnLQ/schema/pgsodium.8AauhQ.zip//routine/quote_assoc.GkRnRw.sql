create function quote_assoc(text, boolean DEFAULT false)
    returns text
    language sql
as
$$
    WITH a AS (SELECT array_agg(CASE WHEN $2 THEN
                                    'new.' || quote_ident(trim(v))
                                ELSE quote_ident(trim(v)) END) as r
               FROM regexp_split_to_table($1, '\s*,\s*') as v)
    SELECT array_to_string(a.r, '::text || ') || '::text' FROM a;
$$;

alter function quote_assoc(text, boolean) owner to supabase_admin;

