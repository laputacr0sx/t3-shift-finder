create function crypto_kdf_derive_from_key(subkey_size integer, subkey_id bigint, context bytea, primary_key uuid)
    returns bytea
    stable
    strict
    security definer
    SET search_path =
            ""
    language plpgsql
as
$$
DECLARE
  key pgsodium.decrypted_key;
BEGIN
  SELECT * INTO STRICT key
    FROM pgsodium.decrypted_key v
  WHERE id = primary_key AND key_type = 'kdf';

  IF key.decrypted_raw_key IS NOT NULL THEN
    RETURN pgsodium.crypto_kdf_derive_from_key(subkey_size, subkey_id, context, key.decrypted_raw_key);
  END IF;
  RETURN pgsodium.derive_key(key.key_id, subkey_size, key.key_context);
END;

$$;

alter function crypto_kdf_derive_from_key(integer, bigint, bytea, uuid) owner to pgsodium_keymaker;

grant execute on function crypto_kdf_derive_from_key(integer, bigint, bytea, uuid) to pgsodium_keyiduser;

