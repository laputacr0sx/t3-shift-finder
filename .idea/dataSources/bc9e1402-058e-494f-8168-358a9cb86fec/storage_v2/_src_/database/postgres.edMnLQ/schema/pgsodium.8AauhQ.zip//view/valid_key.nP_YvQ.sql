create view valid_key
            (id,
             name,
             status,
             key_type,
             key_id,
             key_context,
             created,
             expires,
             associated_data)
as
SELECT key.id,
       key.name,
       key.status,
       key.key_type,
       key.key_id,
       key.key_context,
       key.created,
       key.expires,
       key.associated_data
FROM pgsodium.key
WHERE (key.status = ANY
       (ARRAY ['valid'::pgsodium.key_status, 'default'::pgsodium.key_status]))
  AND CASE
          WHEN key.expires IS NULL
              THEN true
          ELSE key.expires >
               now()
    END;

alter table valid_key
    owner to supabase_admin;

grant select on valid_key to pgsodium_keyiduser;

grant delete, insert, references, select, trigger, truncate, update on valid_key to pgsodium_keyholder;

