create view decrypted_key
            (id,
             status,
             created,
             expires,
             key_type,
             key_id,
             key_context,
             name,
             associated_data,
             raw_key,
             decrypted_raw_key,
             raw_key_nonce,
             parent_key,
             comment)
as
SELECT key.id,
       key.status,
       key.created,
       key.expires,
       key.key_type,
       key.key_id,
       key.key_context,
       key.name,
       key.associated_data,
       key.raw_key,
       CASE
           WHEN key.raw_key IS NULL
               THEN NULL::bytea
           ELSE
               CASE
                   WHEN key.parent_key IS NULL
                       THEN NULL::bytea
                   ELSE pgsodium.crypto_aead_det_decrypt(
                           key.raw_key,
                           convert_to(
                                       key.id::text ||
                                       key.associated_data,
                                       'utf8'::name),
                           key.parent_key,
                           key.raw_key_nonce)
                   END
           END AS decrypted_raw_key,
       key.raw_key_nonce,
       key.parent_key,
       key.comment
FROM pgsodium.key;

alter table decrypted_key
    owner to supabase_admin;

grant delete, insert, references, select, trigger, truncate, update on decrypted_key to pgsodium_keyholder;

