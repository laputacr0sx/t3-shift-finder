create function get_named_keys(filter text DEFAULT '%'::text)
    returns SETOF pgsodium.valid_key
    security definer
    SET search_path =
            ""
    language sql
as
$$
    SELECT * from pgsodium.valid_key vk WHERE vk.name ILIKE filter;
$$;

alter function get_named_keys(text) owner to supabase_admin;

