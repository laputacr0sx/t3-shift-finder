create function enable_security_label_trigger()
    returns void
    security definer
    SET search_path =
            ""
    language sql
as
$$
    ALTER EVENT TRIGGER pgsodium_trg_mask_update ENABLE;
  $$;

alter function enable_security_label_trigger() owner to supabase_admin;

